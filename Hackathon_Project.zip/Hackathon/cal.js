function calculateFootprint() {
  const car = parseFloat(document.getElementById('car').value) || 0;
  const electricity = parseFloat(document.getElementById('electricity').value) || 0;
  const flights = parseFloat(document.getElementById('flights').value) || 0;
  const meals = parseFloat(document.getElementById('meals').value) || 0;

  const carEmission = car * 0.12 * 52;      
  const electricityEmission = electricity * 0.5 * 12; 
  const flightEmission = flights * 250;    
  const mealsEmission = meals * 1.5 * 52;  

  const totalCO2 = (carEmission + electricityEmission + flightEmission + mealsEmission) / 1000;

  const resultBox = document.getElementById('result');
  resultBox.textContent = `Your footprint: ${totalCO2.toFixed(2)} tons CO₂/year`;

  if (totalCO2 < 2) {
    resultBox.style.background = "#c8e6c9";
    resultBox.style.color = "#1b5e20";
  } else if (totalCO2 < 5) {
    resultBox.style.background = "#fff9c4";
    resultBox.style.color = "#f57f17";
  } else {
    resultBox.style.background = "#ffccbc";
    resultBox.style.color = "#b71c1c";
  }
}
